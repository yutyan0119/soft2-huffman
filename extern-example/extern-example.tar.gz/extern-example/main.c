#include <stdio.h>
#include <stdlib.h>
#include "foo.h"

int main(void)
{
    foo();
    
    printf("%d\n",x);
    
    return EXIT_SUCCESS;
}
