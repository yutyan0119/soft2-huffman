#include "foo.h"

void foo(void)
{
    x += 1024;
}
