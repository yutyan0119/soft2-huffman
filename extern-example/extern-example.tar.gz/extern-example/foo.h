#pragma once

void foo(void);
extern int x;

